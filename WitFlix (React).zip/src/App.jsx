// header componenti import et
import Header from './components/Header';
import Banner from './components/Banner';
import Popular from './components/Popular';
import Recommended from './components/Recommended';
import Footer from './components/Footer';
import Movies from './components/Movies';

import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import './App.css';

function App() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route path="/" exact>
          <Banner />
          <Popular />
          <Recommended />
        </Route>

        <Route path="/movies">
          <Movies />
        </Route>
      </Switch>
      {/* componentları ana dosyamızda yerleştirelim */}
      <Footer />
      {/*Router en başında ve en sonunda grup başlıgı gibi kullanıyoruz.*/}
      {/*Switch yer alacak kısımlar alt kısımlar anasayfa dışında olan yerleri içine alıyoyurz route içine */}
    </Router>
  );
}

export default App;
