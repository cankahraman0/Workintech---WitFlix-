import './Footer.css';

function Footer() {
  return (
    <>
      <footer>
        {/* 1.bölüm */}
        <div className="term my-flex2">
          <nav>
            <a href="#">Term Of Use</a>
            <a href="#">Privacy-Policy</a>
            <a href="#">FAQ</a>
            <a href="#">Watch List</a>
          </nav>
          <p>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolore,
            aliquam.
          </p>
        </div>

        {/* 2.bölüm */}
        <div className="social my-flex2">
          <h4>Follow Us</h4>
          <div className="apps-logo">
            <i className="fa-brands fa-facebook"></i>
            <i className="fa-brands fa-youtube"></i>
            <i className="fa-brands fa-x-twitter"></i>
          </div>
        </div>

        {/* 3.bölüm */}
        <div className="apps my-flex2">
          <h4>Apps</h4>
          <div className="apps-logo">
            <i className="fa-brands fa-google-play"></i>
            <i className="fa-brands fa-app-store-ios"></i>
          </div>
        </div>
      </footer>
    </>
  );
}
export default Footer;
