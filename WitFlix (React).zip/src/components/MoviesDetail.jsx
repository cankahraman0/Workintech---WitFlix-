import { useParams } from 'react-router';

function MoviesDetail({ movies }) {
  let id = useParams();
  const filtered = movies.filtered((movie) => movie.id == id.movieId);
  return (
    <>
      <h1>Movies Detail : {id.movieId}</h1>
      <h1>Movies Detail : {filtered[0].name}</h1>
    </>
  );
}

export default MoviesDetail;
