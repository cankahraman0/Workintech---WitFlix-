import './Recommended.css';
import MovieCard from './MovieCard';

function Recommended({ movies }) {
  const filtered = movies.filter((movie) => movie.type === 1);
  return (
    <>
      <section id="recommended">
        <div className="movie-header my-flex u-t">
          <h2 className="h-u">Recommended for you</h2>
          <a href="#">View All</a>
        </div>

        <div className="movies my-flex">
          {filtered.map((movie) => (
            <MovieCard film={movie} />
          ))}
        </div>
      </section>
    </>
  );
}
export default Recommended;
