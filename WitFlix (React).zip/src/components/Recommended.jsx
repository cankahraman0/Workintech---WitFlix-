import './Recommended.css';

function Recommended() {
  return (
    <>
      <section id="recommended">
        <div className="movie-header my-flex u-t">
          <h2 className="h-u">Recommended for you</h2>
          <a href="#">View All</a>
        </div>

        <div className="movies my-flex">
          {/* her bir itemi div olarak düşünürsek */}
          <div className="item zoom-items zoom-items-m b-image-4">
            <div className="item-content">
              <h3>TRON : Ares</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>

          <div className="item zoom-items zoom-items-m b-image-5">
            <div className="item-content">
              <h3>Mr. Robot</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>

          <div className="item zoom-items zoom-items-m b-image-6">
            <div className="item-content">
              <h3>Wednesday</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
export default Recommended;
