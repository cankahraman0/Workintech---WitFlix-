import './Popular.css';

function Popular() {
  return (
    <>
      <section id="popular">
        <div className="movie-header my-flex u-t">
          <h2 className="h-u">Popular Movies</h2>
          <a href="/movies">View All</a>
        </div>

        <div className="movies my-flex">
          {/* her bir itemi div olarak düşünürsek */}
          <div className="item zoom-items zoom-items-m b-image-1">
            <div className="item-content">
              <h3>Battlefield</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>

          <div className="item zoom-items zoom-items-m b-image-2">
            <div className="item-content">
              <h3>SungerBOB</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>

          <div className="item zoom-items zoom-items-m b-image-3">
            <div className="item-content">
              <h3>Arthur</h3>
              <div className="item-detail b-text">
                <span className="age">16+</span>
                <span>2h 21m</span>
              </div>
              <a href="#">
                <i className="fa-solid fa-play"></i> Play Now
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Popular;
