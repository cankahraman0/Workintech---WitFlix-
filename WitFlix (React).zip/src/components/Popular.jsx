import './Popular.css';
import MovieCard from './MovieCard';

function Popular({ movies }) {
  const filtered = movies.filter((movie) => movie.type === 0);
  return (
    <>
      <section id="popular">
        <div className="movie-header my-flex u-t">
          <h2 className="h-u">Popular Movies</h2>
          <a href="/movies">View All</a>
        </div>

        <div className="movies my-flex">
          {filtered.map((movie) => (
            <MovieCard film={movie} />
          ))}
        </div>
      </section>
    </>
  );
}

export default Popular;
