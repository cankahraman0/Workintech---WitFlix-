// header oluşturalım
// export default en son kısma yaz ki componenti başka bir yerde kullanabilelim
// kapsayıcımızı yapalım ki react sıkıntı cıkarmasın "<></>""

// react içerisinde class ları : className olarak vermen gerek

import './Header.css';
function Header() {
  return (
    <>
      <header className="my-flex">
        <a href="/">
          <img className="logo" src="src/assets/img/logo.png" alt="logo" />
        </a>
        <nav className="my-flex">
          <a href="#">Popüler</a>
          <a href="#">Aksiyon</a>
          <a href="#">Komedi</a>
          <a href="#">Korku</a>
        </nav>
        <div className="search my-flex">
          <div className="search-container">
            <input type="text" placeholder="Search..." />
            <i className="fa-solid fa-magnifying-glass search-icon"></i>
            <i className="bell fa-regular fa-bell"></i>
            <i className="profile fa-regular fa-user"></i>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
