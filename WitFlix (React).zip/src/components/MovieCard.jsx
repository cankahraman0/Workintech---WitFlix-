function MovieCard({ film }) {
  return (
    <>
      <div className="item zoom-items zoom-items-m b-image-1">
        <div className="item-content">
          <h3>{film.name}</h3>
          <div className="item-detail b-text">
            <span className="age">{film.age}</span>
            <span>{film.duration}</span>
          </div>
          <a href={`/movie/${film.id}`}>
            <i className="fa-solid fa-play"></i> Play Now
          </a>
        </div>
      </div>
    </>
  );
}

export default MovieCard;
