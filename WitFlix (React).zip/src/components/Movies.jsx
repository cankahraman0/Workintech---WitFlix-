import './Movies.css';
function Movies() {
  return (
    <>
      <h1>WitFlix Movies</h1>
    </>
  );
}

export default Movies;
