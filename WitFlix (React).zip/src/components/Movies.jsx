import MovieCard from './MovieCard';
import './Movies.css';

function Movies({ movies }) {
  return (
    <>
      <h1>Filmler Listesi</h1>
      <div className="movies movies-flex">
        {movies.map((movie) => (
          <MovieCard film={movie} />
        ))}
      </div>
    </>
  );
}
export default Movies;
