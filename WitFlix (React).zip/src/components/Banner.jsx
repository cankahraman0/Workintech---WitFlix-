import './Banner.css';

function Banner() {
  return (
    <>
      <main className="hero-content zoom-items zoom-items-m">
        {/* başlık bölümü */}
        <h1>WHO AM I</h1>

        {/* info bölümü */}
        <div className="movie-info">
          {/* span aynı satırda işlemler yapmak için kullandığımız bir tag */}
          <span className="starts">
            {/* yıldızlar */}
            <i className="fa-solid fa-star"></i>
            <i className="fa-solid fa-star"></i>
            <i className="fa-solid fa-star"></i>
            <i className="fa-solid fa-star"></i>
            <i className="fa-regular fa-star"></i>
          </span>
          <span>7.3 IMDB</span>
          <span className="age">+16</span>
          <span>2h 25m</span>
        </div>

        {/* paragraf bölümü */}
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit
          doloremque, minus odit modi minima aspernatur accusantium nihil. Error
          at asperiores dolorem vero recusandae quod soluta ipsum quibusdam, nam
          reiciendis, ab deleniti impedit blanditiis aliquam cum in qui quo
          velit odio dicta obcaecati harum odit. Aperiam, provident perferendis?
          Reprehenderit minus quis saepe magnam ad, sit quae nam voluptas, quia
          harum voluptatum voluptatibus? Voluptatum suscipit vel voluptatem cum
          iste sunt itaque veniam dolores, nostrum, quibusdam vitae facilis
          incidunt iure fugit repellat. Doloribus dolor, eos, dolorum esse
          nesciunt magnam iusto molestiae obcaecati alias incidunt rem atque
          sint! Velit exercitationem omnis numquam rerum qui!
        </p>

        {/* list bölüm */}
        <ul>
          <li>Starring : Lorem Ipsum</li>
          <li>Genre : Lorem Ipsum</li>
          <li>Tags : Lorem Ipsum</li>
        </ul>

        {/* buton bölümü */}
        <a href="#" className="play">
          <i className="fa-solid fa-play"></i> Play Now
        </a>
      </main>
    </>
  );
}

export default Banner;
